package smarthumans;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = SmartHumans.MODID, name = "SmartHumans", version = "0.1.0", acceptedMinecraftVersions = "[1.12.2]")
public class SmartHumans {
    public static final String MODID = "smarthumans";

    @Mod.Instance(MODID)
    public static SmartHumans instance;

    @SidedProxy(clientSide = "smarthumans.ClientProxy", serverSide = "smarthumans.CommonProxy")
    public static CommonProxy proxy;

    public static SimpleNetworkWrapper network;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        Dialogue.load();
        Skins.load();
        network = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        network.registerMessage(Net.ActionHandler.class, Net.ActionMsg.class, 0, Side.SERVER);
        network.registerMessage(Net.SyncHandler.class, Net.SyncMsg.class, 1, Side.CLIENT);
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "human"), EntityHuman.class, "human", 0,
                this, 64, 3, true, 0x3B6EA5, 0xF2C9A0);
        MinecraftForge.EVENT_BUS.register(new Events());
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent e) {
        e.registerServerCommand(new CmdHumans());
    }
}
