package smarthumans;

/** Серверная/общая часть. Клиентские методы по умолчанию ничего не делают. */
public class CommonProxy {
    public void openGui(EntityHuman h) { }
    public void onSync(int entityId, int hearts, int stage, int mood, String line) { }
}
