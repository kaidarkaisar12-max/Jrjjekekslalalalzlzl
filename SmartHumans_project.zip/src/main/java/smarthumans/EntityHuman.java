package smarthumans;

import com.google.common.base.Optional;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIOpenDoor;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Умный человек: пол, характер, профессия, скин, память об игроках. */
public class EntityHuman extends EntityCreature {
    private static final DataParameter<Integer> GENDER = EntityDataManager.createKey(EntityHuman.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> PERSONALITY = EntityDataManager.createKey(EntityHuman.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> PROFESSION = EntityDataManager.createKey(EntityHuman.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> MOOD = EntityDataManager.createKey(EntityHuman.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> MOVE = EntityDataManager.createKey(EntityHuman.class, DataSerializers.VARINT);
    private static final DataParameter<String> SKIN = EntityDataManager.createKey(EntityHuman.class, DataSerializers.STRING);
    private static final DataParameter<Boolean> MARRIED = EntityDataManager.createKey(EntityHuman.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Optional<UUID>> PARTNER = EntityDataManager.createKey(EntityHuman.class, DataSerializers.OPTIONAL_UNIQUE_ID);

    /** Только сервер. */
    private final Map<UUID, Relation> relations = new HashMap<UUID, Relation>();
    public final Map<String, Integer> lastLine = new HashMap<String, Integer>();
    public final Set<UUID> kin = new HashSet<UUID>();   // родственники (для будущих детей) — на них нельзя жениться
    public UUID followUuid;
    private boolean initialized;

    public EntityHuman(World world) {
        super(world);
        setSize(0.6F, 1.8F);
        ((PathNavigateGround) getNavigator()).setBreakDoors(true);
    }

    @Override
    protected void initEntityAI() {
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new AIFollow(this));
        tasks.addTask(2, new EntityAIOpenDoor(this, true));
        tasks.addTask(3, new AIWander(this));
        tasks.addTask(4, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
        tasks.addTask(5, new EntityAILookIdle(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.3D);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        dataManager.register(GENDER, 0);
        dataManager.register(PERSONALITY, 0);
        dataManager.register(PROFESSION, 0);
        dataManager.register(MOOD, 0);
        dataManager.register(MOVE, 0);
        dataManager.register(SKIN, "custom_male_normal");
        dataManager.register(MARRIED, Boolean.FALSE);
        dataManager.register(PARTNER, Optional.<UUID>absent());
    }

    @Override
    protected boolean canDespawn() { return false; }

    // ---------- геттеры ----------
    public Types.Gender getGender() { return Types.Gender.of(dataManager.get(GENDER)); }
    public Types.Personality getPersonality() { return Types.Personality.of(dataManager.get(PERSONALITY)); }
    public Types.Profession getProfession() { return Types.Profession.of(dataManager.get(PROFESSION)); }
    public String getSkin() { return dataManager.get(SKIN); }
    public int getMood() { return dataManager.get(MOOD); }
    public int getMove() { return dataManager.get(MOVE); }
    public boolean isMarried() { return dataManager.get(MARRIED); }

    public void setMove(int m) {
        dataManager.set(MOVE, m);
        if (m != 0) getNavigator().clearPath();
        if (m != 2) followUuid = null;
    }
    public void addMood(int d) { dataManager.set(MOOD, Math.max(-3, Math.min(3, getMood() + d))); }

    public boolean hasPartner() { return dataManager.get(PARTNER).isPresent(); }
    public boolean isPartner(UUID id) { Optional<UUID> p = dataManager.get(PARTNER); return p.isPresent() && p.get().equals(id); }
    public UUID getPartner() { Optional<UUID> p = dataManager.get(PARTNER); return p.isPresent() ? p.get() : null; }
    public boolean isSpouse(EntityPlayer pl) { return isMarried() && isPartner(pl.getUniqueID()); }

    public void setPartner(UUID id, boolean married) {
        dataManager.set(PARTNER, Optional.of(id));
        dataManager.set(MARRIED, married);
    }
    public void clearPartner() {
        dataManager.set(PARTNER, Optional.<UUID>absent());
        dataManager.set(MARRIED, Boolean.FALSE);
    }

    public Relation rel(UUID player) {
        Relation r = relations.get(player);
        if (r == null) { r = new Relation(); relations.put(player, r); }
        return r;
    }

    // ---------- создание ----------
    public void randomize(Types.Profession prof, Types.Gender gender) {
        Types.Gender g = gender != null ? gender : (rand.nextBoolean() ? Types.Gender.MALE : Types.Gender.FEMALE);
        Types.Profession p = prof != null ? prof : Types.Profession.randomCommon(rand);
        dataManager.set(GENDER, g.ordinal());
        dataManager.set(PROFESSION, p.ordinal());
        dataManager.set(PERSONALITY, rand.nextInt(Types.Personality.values().length));
        dataManager.set(SKIN, Skins.pickSkin(g, p, rand));
        setCustomNameTag(Skins.pickName(g, rand));
        initialized = true;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (!world.isRemote) {
            if (!initialized) randomize(null, null);
            if (ticksExisted % 6000 == 0) {
                int m = getMood();
                if (m != 0) dataManager.set(MOOD, m > 0 ? m - 1 : m + 1);
            }
        }
    }

    // ---------- взаимодействие ----------
    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        if (hand != EnumHand.MAIN_HAND) return false;
        ItemStack held = player.getHeldItem(hand);
        if (!held.isEmpty() && held.getItem() instanceof ItemArmor && isSpouse(player)) {
            if (!world.isRemote) dress(player, held);
            return true;
        }
        if (world.isRemote) SmartHumans.proxy.openGui(this);
        else Interactions.onOpen((EntityPlayerMP) player, this);
        return true;
    }

    /** Супруг может надеть на человека броню/одежду. */
    private void dress(EntityPlayer player, ItemStack held) {
        EntityEquipmentSlot slot = ((ItemArmor) held.getItem()).armorType;
        ItemStack old = getItemStackFromSlot(slot);
        ItemStack put = held.copy();
        put.setCount(1);
        if (!player.capabilities.isCreativeMode) held.shrink(1);
        setItemStackToSlot(slot, put);
        setDropChance(slot, 1.0F);
        if (!old.isEmpty() && !player.inventory.addItemStackToInventory(old)) player.dropItem(old, false);
        if (player instanceof EntityPlayerMP) Interactions.say((EntityPlayerMP) player, this, Dialogue.line(this, "dress.ok", null, player.getName()));
    }

    public void undress(EntityPlayer player) {
        for (EntityEquipmentSlot s : EntityEquipmentSlot.values()) {
            if (s.getSlotType() != EntityEquipmentSlot.Type.ARMOR) continue;
            ItemStack st = getItemStackFromSlot(s);
            if (st.isEmpty()) continue;
            setItemStackToSlot(s, ItemStack.EMPTY);
            if (!player.inventory.addItemStackToInventory(st)) player.dropItem(st, false);
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource src, float amount) {
        Entity e = src.getTrueSource();
        if (!world.isRemote && e instanceof EntityPlayerMP) {
            EntityPlayerMP p = (EntityPlayerMP) e;
            Relation r = rel(p.getUniqueID());
            r.addHearts(-8);
            addMood(-1);
            if (rand.nextInt(3) == 0) Interactions.say(p, this, Dialogue.line(this, "react.hit", null, p.getName()));
            else Net.sync(p, this, "");
        }
        return super.attackEntityFrom(src, amount);
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!world.isRemote && hasPartner()) Interactions.clearPlayerPartnerIfOnline(world, getPartner());
        super.onDeath(cause);
    }

    // ---------- сохранение ----------
    @Override
    public void writeEntityToNBT(NBTTagCompound t) {
        super.writeEntityToNBT(t);
        t.setBoolean("sh_init", initialized);
        t.setInteger("sh_gender", dataManager.get(GENDER));
        t.setInteger("sh_pers", dataManager.get(PERSONALITY));
        t.setInteger("sh_prof", dataManager.get(PROFESSION));
        t.setInteger("sh_mood", dataManager.get(MOOD));
        t.setInteger("sh_move", dataManager.get(MOVE));
        t.setString("sh_skin", dataManager.get(SKIN));
        t.setBoolean("sh_married", isMarried());
        if (hasPartner()) t.setString("sh_partner", getPartner().toString());
        if (followUuid != null) t.setString("sh_follow", followUuid.toString());
        NBTTagList rl = new NBTTagList();
        for (Map.Entry<UUID, Relation> e : relations.entrySet()) {
            NBTTagCompound c = e.getValue().toNBT();
            c.setString("id", e.getKey().toString());
            rl.appendTag(c);
        }
        t.setTag("sh_rel", rl);
        NBTTagList kl = new NBTTagList();
        for (UUID u : kin) { NBTTagCompound c = new NBTTagCompound(); c.setString("id", u.toString()); kl.appendTag(c); }
        t.setTag("sh_kin", kl);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound t) {
        super.readEntityFromNBT(t);
        initialized = t.getBoolean("sh_init");
        if (initialized) {
            dataManager.set(GENDER, t.getInteger("sh_gender"));
            dataManager.set(PERSONALITY, t.getInteger("sh_pers"));
            dataManager.set(PROFESSION, t.getInteger("sh_prof"));
            dataManager.set(SKIN, t.getString("sh_skin"));
        }
        dataManager.set(MOOD, t.getInteger("sh_mood"));
        dataManager.set(MOVE, t.getInteger("sh_move"));
        dataManager.set(MARRIED, t.getBoolean("sh_married"));
        try {
            if (t.hasKey("sh_partner")) dataManager.set(PARTNER, Optional.of(UUID.fromString(t.getString("sh_partner"))));
            if (t.hasKey("sh_follow")) followUuid = UUID.fromString(t.getString("sh_follow"));
            relations.clear();
            NBTTagList rl = t.getTagList("sh_rel", 10);
            for (int i = 0; i < rl.tagCount(); i++) {
                NBTTagCompound c = rl.getCompoundTagAt(i);
                relations.put(UUID.fromString(c.getString("id")), Relation.fromNBT(c));
            }
            kin.clear();
            NBTTagList kl = t.getTagList("sh_kin", 10);
            for (int i = 0; i < kl.tagCount(); i++) kin.add(UUID.fromString(kl.getCompoundTagAt(i).getString("id")));
        } catch (IllegalArgumentException ex) {
            System.err.println("[SmartHumans] Повреждённый UUID в данных человека: " + ex);
        }
    }

    // ---------- ИИ ----------
    static class AIWander extends EntityAIWanderAvoidWater {
        private final EntityHuman h;
        AIWander(EntityHuman h) { super(h, 0.6D); this.h = h; }
        @Override public boolean shouldExecute() { return h.getMove() == 0 && super.shouldExecute(); }
    }

    static class AIFollow extends EntityAIBase {
        private final EntityHuman h;
        private EntityPlayer target;
        AIFollow(EntityHuman h) { this.h = h; setMutexBits(3); }

        @Override public boolean shouldExecute() {
            if (h.getMove() != 2 || h.followUuid == null) return false;
            target = h.world.getPlayerEntityByUUID(h.followUuid);
            return target != null && h.getDistanceSq(target) > 9.0D;
        }
        @Override public boolean shouldContinueExecuting() {
            return target != null && target.isEntityAlive() && h.getMove() == 2 && h.getDistanceSq(target) > 4.0D;
        }
        @Override public void updateTask() {
            h.getLookHelper().setLookPositionWithEntity(target, 10.0F, (float) h.getVerticalFaceSpeed());
            if (h.getDistanceSq(target) > 144.0D) h.setPositionAndUpdate(target.posX, target.posY, target.posZ);
            else h.getNavigator().tryMoveToEntityLiving(target, 1.1D);
        }
        @Override public void resetTask() { target = null; h.getNavigator().clearPath(); }
    }
}
