package smarthumans;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

/** /humans free — очистить запись о партнёре (если он погиб, пока вы были офлайн). */
public class CmdHumans extends CommandBase {
    @Override public String getName() { return "humans"; }
    @Override public String getUsage(ICommandSender s) { return "/humans free"; }
    @Override public int getRequiredPermissionLevel() { return 0; }
    @Override public boolean checkPermission(MinecraftServer server, ICommandSender sender) { return true; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (!(sender instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) sender;
        if (args.length > 0 && args[0].equals("free")) {
            Interactions.clearPlayerPartner(p);
            sender.sendMessage(new TextComponentString("Запись о партнёре очищена."));
        } else sender.sendMessage(new TextComponentString(getUsage(sender)));
    }
}
