package smarthumans;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Серверная логика действий меню. Проверки родства, одного партнёра и стадий — здесь. */
public class Interactions {
    private static final Random R = new Random();
    private static final Map<String, Integer> GIFTS = new HashMap<String, Integer>();
    static {
        GIFTS.put("minecraft:diamond", 12); GIFTS.put("minecraft:emerald", 10); GIFTS.put("minecraft:gold_ingot", 6);
        GIFTS.put("minecraft:cake", 8); GIFTS.put("minecraft:cookie", 4); GIFTS.put("minecraft:golden_apple", 9);
        GIFTS.put("minecraft:red_flower", 6); GIFTS.put("minecraft:yellow_flower", 5); GIFTS.put("minecraft:book", 5);
        GIFTS.put("minecraft:enchanted_book", 7); GIFTS.put("minecraft:iron_ingot", 3); GIFTS.put("minecraft:coal", 1);
        GIFTS.put("minecraft:rotten_flesh", -3); GIFTS.put("minecraft:spider_eye", -2); GIFTS.put("minecraft:dirt", -1);
    }

    // ---------- данные игрока (сохраняются после смерти) ----------
    private static NBTTagCompound pdata(EntityPlayer p) {
        NBTTagCompound root = p.getEntityData();
        if (!root.hasKey(EntityPlayer.PERSISTED_NBT_TAG)) root.setTag(EntityPlayer.PERSISTED_NBT_TAG, new NBTTagCompound());
        NBTTagCompound t = root.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        if (!t.hasKey("smarthumans")) t.setTag("smarthumans", new NBTTagCompound());
        return t.getCompoundTag("smarthumans");
    }
    public static UUID playerPartner(EntityPlayer p) {
        NBTTagCompound t = pdata(p);
        if (!t.hasKey("partner")) return null;
        try { return UUID.fromString(t.getString("partner")); } catch (IllegalArgumentException e) { return null; }
    }
    public static boolean playerMarried(EntityPlayer p) { return pdata(p).getBoolean("married"); }
    public static void setPlayerPartner(EntityPlayer p, UUID id, boolean married) {
        NBTTagCompound t = pdata(p); t.setString("partner", id.toString()); t.setBoolean("married", married);
    }
    public static void clearPlayerPartner(EntityPlayer p) {
        NBTTagCompound t = pdata(p); t.removeTag("partner"); t.removeTag("married");
    }
    public static void clearPlayerPartnerIfOnline(World w, UUID playerId) {
        EntityPlayer p = w.getPlayerEntityByUUID(playerId);
        if (p != null) clearPlayerPartner(p);
    }

    // ---------- вывод реплики ----------
    public static void say(EntityPlayerMP p, EntityHuman h, String line) {
        p.sendMessage(new TextComponentString(TextFormatting.YELLOW + h.getName() + TextFormatting.RESET + ": " + line));
        Net.sync(p, h, line);
    }

    /** Игрок открыл меню: человек здоровается (не чаще раза в 30 секунд). */
    public static void onOpen(EntityPlayerMP p, EntityHuman h) {
        Relation r = h.rel(p.getUniqueID());
        long now = p.world.getTotalWorldTime();
        r.tick(now);
        repair(p, h, r);
        if (now - r.lastGreet > 600L) {
            r.lastGreet = now;
            say(p, h, Dialogue.line(h, "greet." + r.stage.name(), null, p.getName()));
        } else Net.sync(p, h, "");
    }

    /** Данные игрока — источник правды: если человек «помнит» пару, а игрок нет, пара разрывается. */
    private static void repair(EntityPlayerMP p, EntityHuman h, Relation r) {
        if (h.isPartner(p.getUniqueID()) && !h.getUniqueID().equals(playerPartner(p))) {
            h.clearPartner();
            if (r.stage == Types.Stage.DATING || r.stage == Types.Stage.MARRIED) r.stage = Types.Stage.FRIEND;
        }
    }

    // ---------- основной обработчик ----------
    public static void handle(EntityPlayerMP p, EntityHuman h, Types.Action a) {
        Relation r = h.rel(p.getUniqueID());
        r.tick(p.world.getTotalWorldTime());
        repair(p, h, r);
        String line = null;
        switch (a) {
            case CHAT: line = talk(p, h, r, "chat", 0.70, h.getPersonality().chat, 2); break;
            case JOKE: line = talk(p, h, r, "joke", 0.55, h.getPersonality().joke, 3); break;
            case STORY: line = talk(p, h, r, "story", 0.55, h.getPersonality().chat, 3); break;
            case HANDSHAKE: line = talk(p, h, r, "handshake", 0.75, h.getPersonality().chat, 2); break;
            case GIFT: line = gift(p, h, r); break;
            case FLIRT: line = flirt(p, h, r); break;
            case HUG: line = hug(p, h, r); break;
            case KISS: line = kiss(p, h, r); break;
            case BEFRIEND: line = befriend(p, h, r); break;
            case DATE: line = date(p, h, r); break;
            case PROPOSE: line = propose(p, h, r); break;
            case BREAKUP: line = breakup(p, h, r, false); break;
            case FOLLOW:
                if (r.hearts < 5) line = L(h, p, "follow.refuse");
                else { h.setMove(2); h.followUuid = p.getUniqueID(); line = L(h, p, "follow.ok"); }
                break;
            case STAY:
                if (r.hearts < 0) line = L(h, p, "follow.refuse");
                else { h.setMove(1); line = L(h, p, "stay.ok"); }
                break;
            case FREE: h.setMove(0); line = L(h, p, "free.ok"); break;
            case UNDRESS:
                if (h.isSpouse(p)) { h.undress(p); line = L(h, p, "dress.off"); }
                else line = L(h, p, "dress.nospouse");
                break;
            default: break;
        }
        // Партнёр, которого довели до отвращения, уходит сам.
        if ((r.stage == Types.Stage.DATING || r.stage == Types.Stage.MARRIED) && r.hearts <= -30 && h.isPartner(p.getUniqueID())) {
            breakup(p, h, r, true);
            line = L(h, p, "partner.leaves");
        }
        if (line != null) say(p, h, line); else Net.sync(p, h, "");
    }

    private static String L(EntityHuman h, EntityPlayer p, String key) { return Dialogue.line(h, key, null, p.getName()); }

    private static double clamp(double v) { return Math.max(0.05, Math.min(0.95, v)); }

    private static String talk(EntityPlayerMP p, EntityHuman h, Relation r, String key, double base, double pmod, int delta) {
        double chance = clamp(base + pmod + h.getMood() * 0.03 + r.hearts / 250.0 - r.fatigue * 0.04);
        boolean ok = R.nextDouble() < chance;
        r.fatigue++;
        r.addHearts(ok ? delta : -2);
        h.addMood(ok ? 1 : -1);
        String extra = (key.equals("chat") && ok) ? "chat.prof." + h.getProfession().name() : null;
        return Dialogue.line(h, key + (ok ? ".ok" : ".fail"), extra, p.getName());
    }

    // ---------- подарки ----------
    private static String gift(EntityPlayerMP p, EntityHuman h, Relation r) {
        ItemStack held = p.getHeldItemMainhand();
        if (held.isEmpty()) return L(h, p, "gift.none");
        Item it = held.getItem();
        int v = 1;
        String name = it.getRegistryName() == null ? "" : it.getRegistryName().toString();
        if (GIFTS.containsKey(name)) v = GIFTS.get(name);
        else if (it instanceof ItemFood) v = 2;
        if (v > 0) v = Math.max(1, v - r.giftsToday);   // каждый следующий подарок за день ценится меньше
        r.giftsToday++;
        if (!p.capabilities.isCreativeMode) held.shrink(1);
        r.addHearts(v);
        h.addMood(v > 0 ? 1 : -1);
        return L(h, p, v >= 8 ? "gift.great" : v > 0 ? "gift.good" : "gift.bad");
    }

    // ---------- романтика ----------
    /** Возвращает реплику-отказ, если романтика сейчас невозможна. */
    private static String romanceBlock(EntityPlayerMP p, EntityHuman h, Relation r) {
        UUID pp = playerPartner(p);
        if (pp != null && !h.isPartner(p.getUniqueID())) { r.addHearts(-3); return L(h, p, "romance.playertaken"); }
        if (h.hasPartner() && !h.isPartner(p.getUniqueID())) { r.addHearts(-3); return L(h, p, "romance.taken"); }
        return null;
    }

    private static String flirt(EntityPlayerMP p, EntityHuman h, Relation r) {
        String b = romanceBlock(p, h, r);
        if (b != null) return b;
        double chance = clamp(0.40 + h.getPersonality().romance + h.getMood() * 0.03 + r.hearts / 150.0 - r.fatigue * 0.05 - (r.hearts < 15 ? 0.25 : 0));
        boolean ok = R.nextDouble() < chance;
        r.fatigue++; r.addHearts(ok ? 4 : -4); h.addMood(ok ? 1 : -1);
        return Dialogue.line(h, "flirt" + (ok ? ".ok" : ".fail"), null, p.getName());
    }

    private static String hug(EntityPlayerMP p, EntityHuman h, Relation r) {
        String b = romanceBlock(p, h, r);
        if (b != null) return b;
        if (r.hearts < 10) { r.addHearts(-1); return L(h, p, "hug.toosoon"); }
        double chance = clamp(0.55 + h.getPersonality().romance * 0.5 + h.getMood() * 0.03 + r.hearts / 150.0 - r.fatigue * 0.05);
        boolean ok = R.nextDouble() < chance;
        r.fatigue++; r.addHearts(ok ? 3 : -3); h.addMood(ok ? 1 : -1);
        return Dialogue.line(h, "hug" + (ok ? ".ok" : ".fail"), null, p.getName());
    }

    private static String kiss(EntityPlayerMP p, EntityHuman h, Relation r) {
        String b = romanceBlock(p, h, r);
        if (b != null) return b;
        boolean allowed = r.stage.ordinal() >= Types.Stage.DATING.ordinal()
                || (r.stage == Types.Stage.FRIEND && r.hearts >= 40);
        if (!allowed) { r.addHearts(-4); h.addMood(-1); return L(h, p, "kiss.toosoon"); }
        double chance = clamp(0.50 + h.getPersonality().romance + h.getMood() * 0.03 + r.hearts / 200.0 - r.fatigue * 0.05);
        boolean ok = R.nextDouble() < chance;
        r.fatigue++; r.addHearts(ok ? 4 : -4); h.addMood(ok ? 1 : -1);
        return Dialogue.line(h, "kiss" + (ok ? ".ok" : ".fail"), null, p.getName());
    }

    // ---------- стадии отношений ----------
    private static String befriend(EntityPlayerMP p, EntityHuman h, Relation r) {
        if (r.stage.ordinal() >= Types.Stage.FRIEND.ordinal()) return L(h, p, "befriend.already");
        if (r.hearts < 30) return L(h, p, "befriend.tooearly");
        double chance = clamp(0.60 + h.getPersonality().chat + r.hearts / 200.0 - r.fatigue * 0.03);
        if (R.nextDouble() < chance) { r.stage = Types.Stage.FRIEND; r.addHearts(5); h.addMood(1); return L(h, p, "befriend.ok"); }
        r.addHearts(-3); r.fatigue++;
        return L(h, p, "befriend.fail");
    }

    private static String date(EntityPlayerMP p, EntityHuman h, Relation r) {
        String b = romanceBlock(p, h, r);
        if (b != null) return b;
        if (r.stage.ordinal() >= Types.Stage.DATING.ordinal()) return L(h, p, "date.already");
        if (r.stage != Types.Stage.FRIEND) return L(h, p, "date.needfriend");
        if (r.hearts < 60) return L(h, p, "date.tooearly");
        double chance = clamp(0.55 + h.getPersonality().romance + r.hearts / 300.0 - r.fatigue * 0.04);
        if (R.nextDouble() < chance) {
            r.stage = Types.Stage.DATING; r.addHearts(5);
            h.setPartner(p.getUniqueID(), false);
            setPlayerPartner(p, h.getUniqueID(), false);
            heart(h);
            return L(h, p, "date.ok");
        }
        r.addHearts(-5); r.fatigue++;
        return L(h, p, "date.fail");
    }

    private static String propose(EntityPlayerMP p, EntityHuman h, Relation r) {
        if (h.isMarried() && h.isPartner(p.getUniqueID())) return L(h, p, "propose.married");
        String b = romanceBlock(p, h, r);
        if (b != null) return b;
        if (h.kin.contains(p.getUniqueID())) return L(h, p, "propose.kin");
        if (r.stage != Types.Stage.DATING || !h.isPartner(p.getUniqueID())) return L(h, p, "propose.notdating");
        if (r.hearts < 90) return L(h, p, "propose.tooearly");
        ItemStack held = p.getHeldItemMainhand();
        if (held.isEmpty() || held.getItem() != ModItems.RING) return L(h, p, "propose.noring");
        double chance = clamp(0.85 + h.getPersonality().romance - r.fatigue * 0.03);
        if (R.nextDouble() < chance) {
            if (!p.capabilities.isCreativeMode) held.shrink(1);
            r.stage = Types.Stage.MARRIED; r.addHearts(5);
            h.setPartner(p.getUniqueID(), true);
            setPlayerPartner(p, h.getUniqueID(), true);
            heart(h);
            return L(h, p, "propose.ok");
        }
        r.addHearts(-5);
        return L(h, p, "propose.fail");
    }

    private static String breakup(EntityPlayerMP p, EntityHuman h, Relation r, boolean byNpc) {
        if (!h.isPartner(p.getUniqueID())) return L(h, p, "breakup.nopartner");
        boolean married = h.isMarried();
        h.clearPartner();
        clearPlayerPartner(p);
        if (married) h.undress(p);
        r.stage = Types.Stage.FRIEND;
        r.hearts = Math.min(r.hearts, 20) - (byNpc ? 0 : 30);
        r.hearts = Math.max(Relation.MIN, r.hearts);
        r.addHearts(0);
        h.addMood(-2);
        return L(h, p, married ? "breakup.married" : "breakup.ok");
    }

    private static void heart(EntityHuman h) {
        if (h.world instanceof net.minecraft.world.WorldServer)
            ((net.minecraft.world.WorldServer) h.world).spawnParticle(net.minecraft.util.EnumParticleTypes.HEART,
                    h.posX, h.posY + 1.5D, h.posZ, 7, 0.4D, 0.3D, 0.4D, 0.02D);
    }
}
