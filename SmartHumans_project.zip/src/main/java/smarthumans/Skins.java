package smarthumans;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/** Списки скинов (skins.json) и имён (names.json). */
public class Skins {
    private static final Map<String, Map<String, List<String>>> POOLS = new HashMap<String, Map<String, List<String>>>();
    private static final Set<String> SLIM = new HashSet<String>();
    private static final Map<String, List<String>> NAMES = new HashMap<String, List<String>>();

    private static JsonObject read(String path) throws Exception {
        return new JsonParser().parse(new InputStreamReader(Skins.class.getResourceAsStream(path), StandardCharsets.UTF_8)).getAsJsonObject();
    }

    public static void load() {
        try {
            JsonObject o = read("/assets/smarthumans/skins.json");
            JsonObject skins = o.getAsJsonObject("skins");
            for (Map.Entry<String, JsonElement> g : skins.entrySet()) {
                Map<String, List<String>> pools = new HashMap<String, List<String>>();
                for (Map.Entry<String, JsonElement> p : g.getValue().getAsJsonObject().entrySet()) {
                    List<String> l = new ArrayList<String>();
                    for (JsonElement x : p.getValue().getAsJsonArray()) l.add(x.getAsString());
                    pools.put(p.getKey(), l);
                }
                POOLS.put(g.getKey(), pools);
            }
            for (JsonElement x : o.getAsJsonArray("slim")) SLIM.add(x.getAsString());
            JsonObject n = read("/assets/smarthumans/names.json");
            for (Map.Entry<String, JsonElement> e : n.entrySet()) {
                List<String> l = new ArrayList<String>();
                for (JsonElement x : (JsonArray) e.getValue()) l.add(x.getAsString());
                NAMES.put(e.getKey(), l);
            }
        } catch (Exception ex) {
            System.err.println("[SmartHumans] Не удалось загрузить скины/имена: " + ex);
        }
    }

    public static String pickSkin(Types.Gender g, Types.Profession p, Random r) {
        Map<String, List<String>> pools = POOLS.get(g.key());
        if (pools == null) return "custom_male_normal";
        List<String> l = pools.get(p.skinPool);
        if (l == null || l.isEmpty()) l = pools.get("civilian");
        return l.get(r.nextInt(l.size()));
    }

    public static boolean isSlim(String skin) { return SLIM.contains(skin); }

    public static String pickName(Types.Gender g, Random r) {
        List<String> l = NAMES.get(g.key());
        return l == null || l.isEmpty() ? "Житель" : l.get(r.nextInt(l.size()));
    }
}
