package smarthumans;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.util.ResourceLocation;

import java.util.HashMap;
import java.util.Map;

/** Рендер в стиле игрока: модель с толстыми или тонкими руками в зависимости от скина. */
public class RenderHuman extends RenderLiving<EntityHuman> {
    private static final Map<String, ResourceLocation> TEX = new HashMap<String, ResourceLocation>();
    private final ModelPlayer wide = new ModelPlayer(0.0F, false);
    private final ModelPlayer slim = new ModelPlayer(0.0F, true);

    public RenderHuman(RenderManager manager) {
        super(manager, new ModelPlayer(0.0F, false), 0.5F);
        this.mainModel = wide;
        addLayer(new LayerBipedArmor(this));
        addLayer(new LayerHeldItem(this));
    }

    @Override
    public void doRender(EntityHuman e, double x, double y, double z, float yaw, float partial) {
        ModelPlayer m = Skins.isSlim(e.getSkin()) ? slim : wide;
        this.mainModel = m;
        m.rightArmPose = e.getHeldItemMainhand().isEmpty() ? ModelBiped.ArmPose.EMPTY : ModelBiped.ArmPose.ITEM;
        m.leftArmPose = e.getHeldItemOffhand().isEmpty() ? ModelBiped.ArmPose.EMPTY : ModelBiped.ArmPose.ITEM;
        super.doRender(e, x, y, z, yaw, partial);
    }

    @Override
    protected void preRenderCallback(EntityHuman e, float partial) {
        GlStateManager.scale(0.9375F, 0.9375F, 0.9375F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityHuman e) {
        String s = e.getSkin();
        ResourceLocation r = TEX.get(s);
        if (r == null) { r = new ResourceLocation(SmartHumans.MODID, "textures/skins/" + s + ".png"); TEX.put(s, r); }
        return r;
    }
}
