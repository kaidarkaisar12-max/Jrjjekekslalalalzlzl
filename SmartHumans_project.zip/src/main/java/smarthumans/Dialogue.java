package smarthumans;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Шаблонные реплики из assets/smarthumans/dialogue/ru.json.
 * Разметка: {муж|жен} — форма по полу персонажа, %p — имя игрока, %n — имя персонажа.
 * Одна и та же фраза подряд не повторяется.
 */
public class Dialogue {
    private static final Map<String, List<String>> BANKS = new HashMap<String, List<String>>();
    private static final Pattern GENDER = Pattern.compile("\\{([^|}]*)\\|([^}]*)\\}");
    private static final Random RNG = new Random();

    public static void load() {
        try {
            InputStream in = Dialogue.class.getResourceAsStream("/assets/smarthumans/dialogue/ru.json");
            JsonObject o = new JsonParser().parse(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> e : o.entrySet()) {
                List<String> l = new ArrayList<String>();
                for (JsonElement x : e.getValue().getAsJsonArray()) l.add(x.getAsString());
                BANKS.put(e.getKey(), l);
            }
        } catch (Exception ex) {
            System.err.println("[SmartHumans] Не удалось загрузить реплики: " + ex);
        }
    }

    /** Первая существующая из банков фраза. Возвращает null, если банков нет. */
    public static String pick(EntityHuman h, String... keys) {
        for (String k : keys) {
            if (k == null) continue;
            List<String> l = BANKS.get(k);
            if (l == null || l.isEmpty()) continue;
            int idx = RNG.nextInt(l.size());
            Integer last = h.lastLine.get(k);
            if (l.size() > 1 && last != null && last == idx) idx = (idx + 1 + RNG.nextInt(l.size() - 1)) % l.size();
            h.lastLine.put(k, idx);
            return l.get(idx);
        }
        return null;
    }

    /** Смешивает общий банк, банк характера и (необязательно) банк профессии. */
    public static String line(EntityHuman h, String base, String extraFirst, String playerName) {
        String raw;
        if (extraFirst != null && RNG.nextInt(100) < 35) raw = pick(h, extraFirst, base);
        else if (RNG.nextInt(100) < 50) raw = pick(h, base + "." + h.getPersonality().name(), base);
        else raw = pick(h, base);
        if (raw == null) raw = "...";
        return format(raw, h, playerName);
    }

    public static String format(String s, EntityHuman h, String playerName) {
        boolean female = h.getGender() == Types.Gender.FEMALE;
        Matcher m = GENDER.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(female ? m.group(2) : m.group(1)));
        m.appendTail(sb);
        return sb.toString().replace("%p", playerName).replace("%n", h.getName());
    }
}
