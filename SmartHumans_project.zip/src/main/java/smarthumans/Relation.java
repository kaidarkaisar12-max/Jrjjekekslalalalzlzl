package smarthumans;

import net.minecraft.nbt.NBTTagCompound;

/** Отношения одного человека с одним игроком. Сердца ограничены диапазоном -100..100. */
public class Relation {
    public static final int MIN = -100, MAX = 100;

    public int hearts;
    public Types.Stage stage = Types.Stage.STRANGER;
    public int fatigue;          // усталость от общения
    public long lastTick = -1;
    public int giftsToday;
    public long giftDay = -1;
    public long lastGreet = -100000;

    public void addHearts(int d) {
        hearts = Math.max(MIN, Math.min(MAX, hearts + d));
        if (stage == Types.Stage.STRANGER && hearts >= 10) stage = Types.Stage.ACQUAINTANCE;
        if (stage == Types.Stage.ACQUAINTANCE && hearts < 0) stage = Types.Stage.STRANGER;
        if (stage == Types.Stage.FRIEND && hearts < 5) stage = Types.Stage.ACQUAINTANCE;
    }

    /** Усталость спадает со временем, подарки считаются за игровые сутки. */
    public void tick(long now) {
        if (lastTick >= 0 && now > lastTick) fatigue = Math.max(0, fatigue - (int) ((now - lastTick) / 600L));
        lastTick = now;
        long day = now / 24000L;
        if (day != giftDay) { giftDay = day; giftsToday = 0; }
    }

    public NBTTagCompound toNBT() {
        NBTTagCompound t = new NBTTagCompound();
        t.setInteger("hearts", hearts);
        t.setInteger("stage", stage.ordinal());
        t.setInteger("fatigue", fatigue);
        t.setLong("lastTick", lastTick);
        t.setInteger("gifts", giftsToday);
        t.setLong("giftDay", giftDay);
        return t;
    }

    public static Relation fromNBT(NBTTagCompound t) {
        Relation r = new Relation();
        r.hearts = Math.max(MIN, Math.min(MAX, t.getInteger("hearts")));
        r.stage = Types.Stage.of(t.getInteger("stage"));
        r.fatigue = t.getInteger("fatigue");
        r.lastTick = t.getLong("lastTick");
        r.giftsToday = t.getInteger("gifts");
        r.giftDay = t.getLong("giftDay");
        return r;
    }
}
