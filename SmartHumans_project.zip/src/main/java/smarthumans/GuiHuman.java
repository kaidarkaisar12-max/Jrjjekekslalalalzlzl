package smarthumans;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.util.ResourceLocation;

import java.io.IOException;
import java.util.List;

/** Меню взаимодействия (по образцу MCA): главная страница, «Общение», «Отношения». */
public class GuiHuman extends GuiScreen {
    private static final int PAGE_MAIN = 0, PAGE_TALK = 1, PAGE_REL = 2;
    private static final int B_TALK = 100, B_REL = 101, B_CLOSE = 102, B_BACK = 103;
    private static final ResourceLocation ICONS = new ResourceLocation("textures/gui/icons.png");

    private final EntityHuman human;
    private int page = PAGE_MAIN;

    public GuiHuman(EntityHuman human) { this.human = human; }

    @Override
    public void initGui() {
        buttonList.clear();
        int x = width / 2 + 20, w = 130, h = 20, y = height / 2 - 80, gap = 22;
        switch (page) {
            case PAGE_MAIN:
                add(B_TALK, x, y, w, h, "Общение");
                add(B_REL, x, y + gap, w, h, "Отношения");
                add(Types.Action.FOLLOW.ordinal(), x, y + 2 * gap, w, h, Types.Action.FOLLOW.title);
                add(Types.Action.STAY.ordinal(), x, y + 3 * gap, w, h, Types.Action.STAY.title);
                add(Types.Action.FREE.ordinal(), x, y + 4 * gap, w, h, Types.Action.FREE.title);
                if (human.isMarried()) add(Types.Action.UNDRESS.ordinal(), x, y + 5 * gap, w, h, Types.Action.UNDRESS.title);
                add(B_CLOSE, x, y + 7 * gap, w, h, "Закрыть");
                break;
            case PAGE_TALK:
                Types.Action[] talk = {Types.Action.CHAT, Types.Action.JOKE, Types.Action.STORY, Types.Action.HANDSHAKE,
                        Types.Action.GIFT, Types.Action.FLIRT, Types.Action.HUG, Types.Action.KISS};
                for (int i = 0; i < talk.length; i++) add(talk[i].ordinal(), x, y + i * gap, w, h, talk[i].title);
                add(B_BACK, x, y + 9 * gap, w, h, "<< Назад");
                break;
            default:
                Types.Action[] rel = {Types.Action.BEFRIEND, Types.Action.DATE, Types.Action.PROPOSE, Types.Action.BREAKUP};
                for (int i = 0; i < rel.length; i++) add(rel[i].ordinal(), x, y + i * gap, w, h, rel[i].title);
                add(B_BACK, x, y + 9 * gap, w, h, "<< Назад");
        }
    }

    private void add(int id, int x, int y, int w, int h, String text) { buttonList.add(new GuiButton(id, x, y, w, h, text)); }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        switch (b.id) {
            case B_TALK: page = PAGE_TALK; initGui(); return;
            case B_REL: page = PAGE_REL; initGui(); return;
            case B_BACK: page = PAGE_MAIN; initGui(); return;
            case B_CLOSE: mc.displayGuiScreen(null); return;
            default:
                SmartHumans.network.sendToServer(new Net.ActionMsg(human.getEntityId(), b.id));
        }
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        int cx = width / 2 - 90, top = height / 2 - 90;
        ClientProxy.Data d = ClientProxy.data(human.getEntityId());
        Types.Gender g = human.getGender();

        drawCenteredString(fontRenderer, human.getName(), cx, top, 0xFFFFFF);
        drawCenteredString(fontRenderer, human.getProfession().title + " · " + human.getPersonality().title, cx, top + 11, 0xAAAAAA);
        GuiInventory.drawEntityOnScreen(cx, top + 135, 55, cx - mx, top + 60 - my, human);

        int hy = top + 145;
        mc.getTextureManager().bindTexture(ICONS);
        int full = Math.max(0, d.hearts) / 10;
        for (int i = 0; i < 10; i++) {
            drawTexturedModalRect(cx - 50 + i * 10, hy, 16, 0, 9, 9);
            if (i < full) drawTexturedModalRect(cx - 50 + i * 10, hy, 52, 0, 9, 9);
        }
        String st = Types.Stage.of(d.stage).title(g) + " · " + d.hearts + "/100";
        drawCenteredString(fontRenderer, st, cx, hy + 12, 0xFFAAAA);
        String[] moods = {"Подавлен", "Расстроен", "Хмур", "Спокоен", "Доволен", "Радостен", "В восторге"};
        String mood = moods[Math.max(0, Math.min(6, d.mood + 3))];
        drawCenteredString(fontRenderer, "Настроение: " + mood, cx, hy + 23, 0xCCCCCC);

        if (!d.line.isEmpty()) {
            List<String> lines = fontRenderer.listFormattedStringToWidth(d.line, 150);
            int ly = hy + 40;
            for (String s : lines) { drawCenteredString(fontRenderer, s, cx, ly, 0xFFFF88); ly += 10; }
        }
        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
