package smarthumans;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = SmartHumans.MODID)
public class ClientProxy extends CommonProxy {
    /** Данные об отношениях, пришедшие с сервера. */
    public static class Data {
        public int hearts, stage, mood;
        public String line = "";
        public long lineTime;
    }
    public static final Map<Integer, Data> CACHE = new HashMap<Integer, Data>();

    public static Data data(int entityId) {
        Data d = CACHE.get(entityId);
        if (d == null) { d = new Data(); CACHE.put(entityId, d); }
        return d;
    }

    @Override
    public void openGui(EntityHuman h) { Minecraft.getMinecraft().displayGuiScreen(new GuiHuman(h)); }

    @Override
    public void onSync(final int id, final int hearts, final int stage, final int mood, final String line) {
        Minecraft.getMinecraft().addScheduledTask(new Runnable() {
            @Override public void run() {
                Data d = data(id);
                d.hearts = hearts; d.stage = stage; d.mood = mood;
                if (line != null && !line.isEmpty()) { d.line = line; d.lineTime = System.currentTimeMillis(); }
            }
        });
    }

    @SubscribeEvent
    public static void onModels(ModelRegistryEvent e) {
        RenderingRegistry.registerEntityRenderingHandler(EntityHuman.class, RenderHuman::new);
        ModelLoader.setCustomModelResourceLocation(ModItems.RING, 0,
                new ModelResourceLocation(ModItems.RING.getRegistryName(), "inventory"));
    }
}
