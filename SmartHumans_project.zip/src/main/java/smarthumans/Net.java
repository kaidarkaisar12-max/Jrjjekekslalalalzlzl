package smarthumans;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Сетевые сообщения. Все обработчики исполняются в главном потоке сервера/клиента. */
public class Net {
    /** Клиент -> сервер: действие меню. */
    public static class ActionMsg implements IMessage {
        public int entityId, action;
        public ActionMsg() {}
        public ActionMsg(int entityId, int action) { this.entityId = entityId; this.action = action; }
        @Override public void fromBytes(ByteBuf b) { entityId = b.readInt(); action = b.readInt(); }
        @Override public void toBytes(ByteBuf b) { b.writeInt(entityId); b.writeInt(action); }
    }

    public static class ActionHandler implements IMessageHandler<ActionMsg, IMessage> {
        @Override
        public IMessage onMessage(final ActionMsg m, final MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            p.getServerWorld().addScheduledTask(new Runnable() {
                @Override public void run() {
                    Entity e = p.world.getEntityByID(m.entityId);
                    if (!(e instanceof EntityHuman) || e.getDistanceSq(p) > 64.0D) return;   // не дальше 8 блоков
                    Types.Action a = Types.Action.fromId(m.action);
                    if (a == null) return;
                    Interactions.handle(p, (EntityHuman) e, a);
                }
            });
            return null;
        }
    }

    /** Сервер -> клиент: сердца, стадия, настроение и последняя реплика. */
    public static class SyncMsg implements IMessage {
        public int entityId, hearts, stage, mood;
        public String line = "";
        public SyncMsg() {}
        @Override public void fromBytes(ByteBuf b) {
            entityId = b.readInt(); hearts = b.readInt(); stage = b.readInt(); mood = b.readInt();
            line = ByteBufUtils.readUTF8String(b);
        }
        @Override public void toBytes(ByteBuf b) {
            b.writeInt(entityId); b.writeInt(hearts); b.writeInt(stage); b.writeInt(mood);
            ByteBufUtils.writeUTF8String(b, line == null ? "" : line);
        }
    }

    public static class SyncHandler implements IMessageHandler<SyncMsg, IMessage> {
        @Override
        public IMessage onMessage(SyncMsg m, MessageContext ctx) {
            SmartHumans.proxy.onSync(m.entityId, m.hearts, m.stage, m.mood, m.line);
            return null;
        }
    }

    public static void sync(EntityPlayerMP p, EntityHuman h, String line) {
        Relation r = h.rel(p.getUniqueID());
        SyncMsg m = new SyncMsg();
        m.entityId = h.getEntityId(); m.hearts = r.hearts; m.stage = r.stage.ordinal(); m.mood = h.getMood();
        m.line = line == null ? "" : line;
        SmartHumans.network.sendTo(m, p);
    }
}
