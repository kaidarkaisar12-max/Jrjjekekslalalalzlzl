package smarthumans;

import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Заменяет ванильных жителей на людей мода (профессия сохраняется). */
public class Events {
    @SubscribeEvent
    public void onJoin(EntityJoinWorldEvent e) {
        if (!(e.getEntity() instanceof EntityVillager) || e.getWorld().isRemote) return;
        EntityVillager v = (EntityVillager) e.getEntity();
        String path = null;
        try {
            if (v.getProfessionForge() != null && v.getProfessionForge().getRegistryName() != null)
                path = v.getProfessionForge().getRegistryName().getResourcePath();
        } catch (Exception ignored) { }
        final Types.Profession prof = Types.Profession.fromVanilla(path);
        final World w = e.getWorld();
        final double x = v.posX, y = v.posY, z = v.posZ;
        e.setCanceled(true);
        FMLCommonHandler.instance().getMinecraftServerInstance().addScheduledTask(new Runnable() {
            @Override public void run() {
                EntityHuman h = new EntityHuman(w);
                h.setPosition(x, y, z);
                h.randomize(prof, null);
                w.spawnEntity(h);
            }
        });
    }
}
