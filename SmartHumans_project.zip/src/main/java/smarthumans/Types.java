package smarthumans;

import java.util.Locale;
import java.util.Random;

/** Перечисления: пол, характер, профессия, стадия отношений, действия меню. */
public final class Types {
    private Types() {}

    public enum Gender {
        MALE, FEMALE;
        public String key() { return name().toLowerCase(Locale.ROOT); }
        public static Gender of(int i) { return values()[Math.floorMod(i, values().length)]; }
    }

    public enum Personality {
        FRIENDLY("Добряк", 0.10, 0.05, 0.00),
        SHY("Скромник", -0.05, -0.05, -0.15),
        GRUMPY("Ворчун", -0.10, -0.15, -0.10),
        CHEERFUL("Весельчак", 0.05, 0.15, 0.05),
        SERIOUS("Серьёзный", 0.00, -0.10, -0.05),
        DREAMER("Мечтатель", 0.05, 0.00, 0.10);

        public final String title;
        public final double chat, joke, romance;

        Personality(String title, double chat, double joke, double romance) {
            this.title = title; this.chat = chat; this.joke = joke; this.romance = romance;
        }
        public static Personality of(int i) { return values()[Math.floorMod(i, values().length)]; }
    }

    public enum Profession {
        CIVILIAN("civilian", "Горожанин"), FARMER("farmer", "Фермер"), BAKER("baker", "Пекарь"),
        BUTCHER("butcher", "Мясник"), LIBRARIAN("librarian", "Библиотекарь"), MINER("miner", "Шахтёр"),
        PRIEST("priest", "Священник"), SMITH("smith", "Кузнец"), GUARD("guard", "Стражник"),
        WARRIOR("warrior", "Воин"), POLICE("police", "Полицейский");

        public final String skinPool, title;
        Profession(String skinPool, String title) { this.skinPool = skinPool; this.title = title; }
        public static Profession of(int i) { return values()[Math.floorMod(i, values().length)]; }

        public static Profession fromVanilla(String path) {
            if (path == null) return CIVILIAN;
            switch (path) {
                case "farmer": return FARMER;
                case "librarian": return LIBRARIAN;
                case "priest": return PRIEST;
                case "smith": return SMITH;
                case "butcher": return BUTCHER;
                default: return CIVILIAN;
            }
        }
        public static Profession randomCommon(Random r) {
            Profession[] c = {CIVILIAN, CIVILIAN, CIVILIAN, FARMER, BAKER, BUTCHER, LIBRARIAN, MINER, PRIEST, SMITH};
            return c[r.nextInt(c.length)];
        }
    }

    public enum Stage {
        STRANGER("Незнакомец"), ACQUAINTANCE("Знакомый"), FRIEND("Друг"), DATING("Пара"), MARRIED("Супруг");
        public final String title;
        Stage(String title) { this.title = title; }
        public static Stage of(int i) { return values()[Math.floorMod(i, values().length)]; }
        public String title(Gender g) {
            if (this == MARRIED) return g == Gender.FEMALE ? "Супруга" : "Супруг";
            if (this == ACQUAINTANCE && g == Gender.FEMALE) return "Знакомая";
            if (this == FRIEND && g == Gender.FEMALE) return "Подруга";
            return title;
        }
    }

    public enum Action {
        CHAT("Побеседовать"), JOKE("Пошутить"), STORY("Рассказать историю"), HANDSHAKE("Пожать руку"),
        GIFT("Подарить"), FLIRT("Пофлиртовать"), HUG("Обнять"), KISS("Поцеловать"),
        BEFRIEND("Предложить дружить"), DATE("Позвать на свидание"), PROPOSE("Сделать предложение"),
        BREAKUP("Расстаться"), FOLLOW("Идти за мной"), STAY("Стоять здесь"), FREE("Свободно"),
        UNDRESS("Снять одежду");

        public final String title;
        Action(String title) { this.title = title; }
        public static Action fromId(int id) {
            Action[] v = values();
            return id >= 0 && id < v.length ? v[id] : null;
        }
    }
}
